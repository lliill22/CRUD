package org.example.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CRUDapp {

    public static void main(String[] args) {
        SpringApplication.run(CRUDapp.class, args);
    }

}
